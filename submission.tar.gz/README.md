# Game Details

This is the classic Atari 2600 Pinball implementation in GBA.
Use the return button on the start screen, win screen or lose screen to play/replay the game.
Use the delete button to return to the start screen at any time.
Use the up arrow to control the flippers in the game.
Hit the obstacle with the ball to score a point and you have 3 lives to win the game.
Hit the ball with the paddle to make it move in a direction and reach 50 points to win.

