/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --resize=240x160 --mode=3 title title.png 
 * Time-stamp: Saturday 04/02/2022, 02:34:12
 * 
 * Image Information
 * -----------------
 * title.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLE_H
#define TITLE_H

extern const unsigned short title[38400];
#define TITLE_SIZE 76800
#define TITLE_LENGTH 38400
#define TITLE_WIDTH 240
#define TITLE_HEIGHT 160

#endif

