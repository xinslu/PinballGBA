/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=112x112 trolled trolled.png 
 * Time-stamp: Wednesday 03/30/2022, 12:48:59
 * 
 * Image Information
 * -----------------
 * trolled.png 112@112
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TROLLED_H
#define TROLLED_H

extern const unsigned short trolled[12544];
#define TROLLED_SIZE 25088
#define TROLLED_LENGTH 12544
#define TROLLED_WIDTH 112
#define TROLLED_HEIGHT 112

#endif

